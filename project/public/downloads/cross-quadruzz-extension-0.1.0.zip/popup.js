const BASE='https://cross-quadruzz.l-busslerberto.chatgpt.site';
const app=document.querySelector('#app');
const requestedActionMode=new URLSearchParams(location.search).get('action');
const actionPopup=window.top===window;
const actionMode=actionPopup?(requestedActionMode||'popup'):requestedActionMode;
const actionPopupPort=actionPopup?chrome.runtime.connect({name:'quadruzz-action-popup'}):null;
const DISPLAYED_NOTES_KEY='displayedNoteVersions';
let actionPopupRevealed=false;
const imageUrls=new Map();
const imageLoads=new Map();
let storedImageCachePromise=null;
let refreshTimer=null;
let connectInProgress=false;
let stopped=false;
let latestData=null;
let latestImages=[];
let pickerOpen=false;
let noteOpen=false;
let roleFilter='';
let noteDraft='';
let noteLastValid='';
let savingRole=false;
let savingNote=false;
let pendingRole=null;
let pendingNote=null;
let pendingNoteSet=false;
let pendingNoteUpdatedAt=null;
let nextLoadSequence=0;
let appliedLoadSequence=0;
let appliedAccessSequence=0;
let lastRenderSignature='';
let pickerDesiredHeight=0;
let roleLayoutFrame=null;
let standaloneRole=false;
let standaloneNote=false;
let standaloneNotification=false;
let pendingPanel=null;
let overlayVisible=false;
let selectedRoleIndex=0;
let presentationId=0;
let focusRequest=0;
let notifications=[];
const notificationTimers=new Map();
let displayedNoteVersions=null;
let displayedNoteVersionsPromise=null;
const freshNoteUsers=new Set();
const animatedFreshNoteUsers=new Set();
const freshNoteTimers=new Map();

function focusOverlayInput(){
  const request=++focusRequest;
  const tryFocus=attempt=>{
    if(request!==focusRequest||!overlayVisible)return;
    const input=document.querySelector('#role-filter,#note-input');
    if(!input)return;
    input.focus({preventScroll:true});
    input.setSelectionRange(input.value.length,input.value.length);
    if(document.activeElement!==input&&attempt<5)setTimeout(()=>tryFocus(attempt+1),16*(attempt+1));
  };
  requestAnimationFrame(()=>tryFocus(0));
}

function notificationKey(notification){return `${notification.userId}:${notification.noteUpdatedAt}`}
function clearNotifications(render=true){notifications=[];for(const timer of notificationTimers.values())clearTimeout(timer);notificationTimers.clear();document.querySelector('.note-notifications')?.remove();if(render&&latestData)renderMembers()}
function removeNotification(key){notifications=notifications.filter(item=>notificationKey(item)!==key);const timer=notificationTimers.get(key);if(timer)clearTimeout(timer);notificationTimers.delete(key);if(!notifications.length&&!pickerOpen&&!noteOpen&&standaloneNotification){if(actionPopup)window.close();else hideOverlayNow();return}if(latestData)renderMembers()}
function addNotification(notification){if(!notification?.note||notification.userId===latestData?.currentUserId)return;const remaining=Math.min(5000,Number(notification.expiresAt||Date.now()+5000)-Date.now());if(remaining<=0)return;const key=notificationKey(notification);notifications=notifications.filter(item=>notificationKey(item)!==key);notifications.unshift(notification);const previous=notificationTimers.get(key);if(previous)clearTimeout(previous);notificationTimers.set(key,setTimeout(()=>removeNotification(key),remaining));if(latestData)renderMembers()}
function notificationMarkup(){if(!notifications.length)return'';return `<div class="note-notifications">${notifications.map(notification=>{const twoLines=noteUsesTwoLines(notification.note);return `<div class="note-notification${twoLines?' two-lines':''}"><div class="notification-identity"><span class="notification-name">${esc(notification.displayName)}</span><span class="notification-role">${esc(notification.actingState||'-')}</span></div><div class="notification-note">${esc(notification.note)}</div></div>`}).join('')}</div>`}
function notificationHeight(){if(!notifications.length)return 0;return notifications.reduce((height,item)=>height+(noteUsesTwoLines(item.note)?46:34),0)+(notifications.length-1)*2}
async function loadDisplayedNoteVersions(){
  if(displayedNoteVersions)return displayedNoteVersions;
  if(!displayedNoteVersionsPromise)displayedNoteVersionsPromise=chrome.storage.session.get(DISPLAYED_NOTES_KEY).then(stored=>stored[DISPLAYED_NOTES_KEY]||{}).catch(()=>({}));
  displayedNoteVersions=await displayedNoteVersionsPromise;
  return displayedNoteVersions;
}
function flagFreshNote(userId){
  freshNoteUsers.add(userId);
  animatedFreshNoteUsers.delete(userId);
  const previous=freshNoteTimers.get(userId);
  if(previous)clearTimeout(previous);
  freshNoteTimers.set(userId,setTimeout(()=>{
    freshNoteUsers.delete(userId);
    animatedFreshNoteUsers.delete(userId);
    freshNoteTimers.delete(userId);
    document.querySelectorAll('.note-fresh').forEach(element=>{if(element.dataset.noteUser===userId){element.classList.remove('note-fresh');element.removeAttribute('data-note-fresh')}});
  },1800));
}
function startFreshNoteAnimations(){
  document.querySelectorAll('[data-note-fresh="true"]').forEach(element=>{
    const userId=element.dataset.noteUser;
    if(!userId||animatedFreshNoteUsers.has(userId))return;
    animatedFreshNoteUsers.add(userId);
    element.classList.add('note-fresh');
  });
}
async function markFreshNotes(data){
  if(!data?.members)return false;
  const displayed=await loadDisplayedNoteVersions();
  let changed=false;
  let storageChanged=false;
  for(const member of data.members){
    if(member.userId===data.currentUserId)continue;
    const version=Number(member.noteUpdatedAt||0);
    if(member.note&&version&&Number(displayed[member.userId]||0)!==version){flagFreshNote(member.userId);changed=true}
    if(Number(displayed[member.userId]||0)!==version){displayed[member.userId]=version;storageChanged=true}
  }
  if(storageChanged)void chrome.storage.session.set({[DISPLAYED_NOTES_KEY]:displayed});
  return changed;
}
function receiveVisibleMemberNote(notification){
  if(!notification?.userId||!notification.note)return;
  flagFreshNote(notification.userId);
  void loadDisplayedNoteVersions().then(displayed=>{displayed[notification.userId]=Number(notification.noteUpdatedAt||0);return chrome.storage.session.set({[DISPLAYED_NOTES_KEY]:displayed})});
  const member=latestData?.members.find(item=>item.userId===notification.userId);
  if(member){member.note=notification.note;member.noteUpdatedAt=notification.noteUpdatedAt;member.actingState=notification.actingState;renderMembers()}
  void loadMembers(false);
}
document.querySelector('#close').addEventListener('click',()=>{if(actionPopup){window.close();return}try{const sent=chrome.runtime.sendMessage({type:'quadruzz-close'});if(sent?.catch)sent.catch(()=>{})}catch{/* Context already closed. */}});
document.querySelector('#open-hq-home').addEventListener('click',()=>{try{const sent=chrome.runtime.sendMessage({type:'quadruzz-open-hq'});if(sent?.catch)sent.catch(()=>{})}catch{/* Context already closed. */}});
window.addEventListener('keydown',event=>{
  const popupToggle=event.code==='KeyQ'&&event.altKey&&event.shiftKey&&!event.ctrlKey&&!event.metaKey;
  const retiredPopupToggle=event.code==='KeyW'&&event.altKey&&event.shiftKey&&!event.ctrlKey&&!event.metaKey;
  const roleToggle=event.code==='KeyD'&&event.altKey&&event.shiftKey&&!event.ctrlKey&&!event.metaKey;
  const noteToggle=event.code==='KeyS'&&event.altKey&&event.shiftKey&&!event.ctrlKey&&!event.metaKey;
  if(event.repeat||(!popupToggle&&!retiredPopupToggle&&!roleToggle&&!noteToggle))return;
  if(retiredPopupToggle){event.preventDefault();event.stopImmediatePropagation();return}
  if(actionPopup&&actionMode==='notification'){
    event.preventDefault();
    event.stopImmediatePropagation();
    actionPopupPort?.postMessage({type:'quadruzz-action-replace-request',panel:popupToggle?'popup':roleToggle?'role':'note'});
    return
  }
  if(actionPopup&&popupToggle)return;
  event.preventDefault();
  event.stopImmediatePropagation();
  if(actionPopup){
    if(roleToggle){requestRolePickerToggle();return}
    if(noteToggle){requestNoteToggle();return}
  }
  try{
    const type=popupToggle?'quadruzz-toggle':roleToggle?'quadruzz-role-toggle':'quadruzz-note-toggle';
    const sent=chrome.runtime.sendMessage({type});
    if(sent?.catch)sent.catch(()=>{});
  }catch{/* Context already closed. */}
},true);chrome.runtime.onMessage.addListener(message=>{if(message?.type==='quadruzz-connect-started'||message?.type==='quadruzz-access-checking'){connectInProgress=true;connectingView()}if(message?.type==='quadruzz-connect-complete'||message?.type==='quadruzz-access-approved'){connectInProgress=false;void loadMembers(false)}if(message?.type==='quadruzz-connect-cancelled'){connectInProgress=false;signInView()}if(message?.type==='quadruzz-access-pending'){connectInProgress=false;waitingView()}});
function actionPopupIsVisible(){return !document.hidden&&document.hasFocus()}
function reportActionPopupVisibility(){actionPopupPort?.postMessage({type:'quadruzz-action-visibility',visible:actionPopupIsVisible(),mode:actionMode})}
if(actionPopupPort){document.addEventListener('visibilitychange',reportActionPopupVisibility);window.addEventListener('focus',reportActionPopupVisibility);window.addEventListener('blur',reportActionPopupVisibility);reportActionPopupVisibility()}
actionPopupPort?.onMessage.addListener(message=>{if(message?.type==='quadruzz-action-close')window.close();if(message?.type==='quadruzz-action-replace'&&['popup','role','note'].includes(message.panel)){clearNotifications(false);location.replace(`popup.html?action=${message.panel}`);return}if(message?.type==='quadruzz-action-note'&&actionPopupIsVisible()){if(actionMode==='notification')addNotification(message.notification);else receiveVisibleMemberNote(message.notification);actionPopupPort.postMessage({type:'quadruzz-action-note-rendered',deliveryId:message.deliveryId})}if(message?.type==='quadruzz-action-panel-toggle'){if(message.panel==='role')requestRolePickerToggle();if(message.panel==='note')requestNoteToggle()}});
window.addEventListener('message',event=>{
  if(event.source!==parent)return;
  if(event.data?.type==='quadruzz-dismiss-menus'&&pickerOpen){closeRolePicker();return}
  if(event.data?.type==='quadruzz-role-toggle'){requestRolePickerToggle();return}
  if(event.data?.type==='quadruzz-note-toggle'){requestNoteToggle();return}
  if(event.data?.type==='quadruzz-note-notification'){addNotification(event.data.notification);return}
  if(event.data?.type==='quadruzz-clear-notifications'){clearNotifications(false);return}
  if(event.data?.type==='quadruzz-reset-panels'){
    focusRequest+=1;overlayVisible=false;pickerOpen=false;noteOpen=false;standaloneRole=false;standaloneNote=false;standaloneNotification=false;pendingPanel=null;selectedRoleIndex=0;roleFilter='';noteDraft='';noteLastValid='';pickerDesiredHeight=0;
    clearNotifications(false);
    document.documentElement.classList.remove('standalone-role','standalone-note','standalone-notification');
    document.querySelectorAll('.role-picker,.note-editor,.note-notifications').forEach(element=>element.remove());
    if(latestData)renderMembers();
    window.parent.postMessage({type:'quadruzz-panels-reset',presentationId:Number(event.data.presentationId||0)},'*');
    return
  }
  if(event.data?.type==='quadruzz-picker-prepared'){const panel=pendingPanel;pendingPanel=null;if(panel==='role'){pickerOpen=true;noteOpen=false;selectedRoleIndex=0;roleFilter=''}else if(panel==='note'){noteOpen=true;pickerOpen=false;noteDraft='';noteLastValid=''}renderMembers();return}
  if(event.data?.type==='quadruzz-overlay-hidden'){focusRequest+=1;overlayVisible=false;pickerOpen=false;noteOpen=false;standaloneRole=false;standaloneNote=false;standaloneNotification=false;clearNotifications(false);pendingPanel=null;selectedRoleIndex=0;roleFilter='';noteDraft='';noteLastValid='';pickerDesiredHeight=0;document.documentElement.classList.remove('standalone-role','standalone-note','standalone-notification');document.querySelectorAll('.role-picker,.note-editor').forEach(element=>element.remove());return}
  if(event.data?.type==='quadruzz-presented'){
    if(Number(event.data.presentationId||0)===presentationId){startFreshNoteAnimations();focusOverlayInput()}
    return
  }
  if(event.data?.type==='quadruzz-overlay-mode'){
    presentationId=Number(event.data.presentationId||0);
    overlayVisible=event.data.visible===true;
    if(!overlayVisible)return;
    const wasStandaloneRole=standaloneRole;
    const wasStandaloneNote=standaloneNote;
    standaloneRole=event.data.mode==='role';
    standaloneNote=event.data.mode==='note';
    standaloneNotification=event.data.mode==='notification';
    document.documentElement.classList.toggle('standalone-role',standaloneRole);
    document.documentElement.classList.toggle('standalone-note',standaloneNote);
    document.documentElement.classList.toggle('standalone-notification',standaloneNotification);
    if(event.data.mode==='popup'){
      clearNotifications(false);
      pickerOpen=false;
      noteOpen=false;
      roleFilter='';
      noteDraft='';
      noteLastValid='';
    }else if(standaloneRole&&!wasStandaloneRole){pickerOpen=true;noteOpen=false;selectedRoleIndex=0;}
    else if(standaloneNote&&!wasStandaloneNote){noteOpen=true;pickerOpen=false;noteDraft='';noteLastValid='';}
    if(latestData){renderMembers();if(event.data.mode==='popup')void markFreshNotes(latestData).then(changed=>{if(changed)renderMembers()})}
  }
});
document.addEventListener('pointerdown',event=>{if(pickerOpen&&!event.target.closest('.role-picker,.role-trigger'))closeRolePicker();if(noteOpen&&!event.target.closest('.note-editor,.note-trigger'))closeNoteEditor()});

function storageCall(method,value){return new Promise((resolve,reject)=>{try{chrome.storage.local[method](value,result=>{try{const failure=chrome.runtime.lastError;if(failure)reject(new Error(failure.message));else resolve(result)}catch(error){reject(error)}})}catch(error){reject(error)}})}
const storage={get:key=>storageCall('get',key),set:value=>storageCall('set',value),remove:key=>storageCall('remove',key)};
function measuredHeight(){const base=document.querySelector('header').offsetHeight+app.scrollHeight;return Math.max(base,pickerDesiredHeight)}
let sizeReportFrame=0;
let lastActionPopupHeight=0;
function reportSize(){const height=measuredHeight();if(actionPopup){const nextHeight=Math.min(545,Math.max(25,height));if(nextHeight!==lastActionPopupHeight){lastActionPopupHeight=nextHeight;document.documentElement.style.height=nextHeight+'px'}return}window.parent.postMessage({type:'quadruzz-resize',height},'*')}
function scheduleSizeReport(){if(sizeReportFrame)return;sizeReportFrame=requestAnimationFrame(()=>{sizeReportFrame=0;reportSize()})}
function reportReady(){const height=measuredHeight();if(actionPopup){reportSize();if(!actionPopupRevealed){actionPopupRevealed=true;requestAnimationFrame(()=>{document.documentElement.classList.remove('action-popup-pending');requestAnimationFrame(()=>{startFreshNoteAnimations();if(actionMode==='role'||actionMode==='note')focusOverlayInput()})})}else requestAnimationFrame(startFreshNoteAnimations);return}window.parent.postMessage({type:'quadruzz-picker-visibility',visible:pickerOpen||noteOpen},'*');window.parent.postMessage({type:'quadruzz-ready',presentationId,height},'*')}
async function api(path,options={}){const{token}=await storage.get('token');const headers={...options.headers,...(token&&{authorization:`Bearer ${token}`})};const response=await fetch(`${BASE}${path}`,{...options,headers});if(response.status===401)await storage.remove(['token','profileImageCache']);return response}
async function pulseActivity(){try{const stored=await storage.get(['token','extensionActivitySessionId','extensionActivityPulseAt']);if(!stored.token)return;const now=Date.now();if(now-(stored.extensionActivityPulseAt||0)<15000)return;const extensionSessionId=stored.extensionActivitySessionId||crypto.randomUUID();await storage.set({extensionActivitySessionId,extensionActivityPulseAt:now});const response=await fetch(`${BASE}/api/extension`,{method:'POST',headers:{authorization:`Bearer ${stored.token}`,'content-type':'application/json'},body:JSON.stringify({extensionAction:'heartbeat',extensionSessionId})});if(response.status===401)await storage.remove(['token','extensionActivityPulseAt','profileImageCache']);else if(!response.ok)await storage.remove('extensionActivityPulseAt')}catch(error){if(!stopInvalidContext(error))try{await storage.remove('extensionActivityPulseAt')}catch{/* The next member refresh retries. */}}}
function requireFullPopup(){if(standaloneRole||standaloneNote)window.parent.postMessage({type:'quadruzz-require-popup'},'*')}
function connectingView(){requireFullPopup();if(!document.querySelector('#connect-progress'))app.innerHTML='<div class="connect"><button class="primary" id="connect-progress" disabled>Connecting to Cross…</button></div>';reportReady()}
function waitingView(){requireFullPopup();if(!document.querySelector('#open-hq')){app.innerHTML='<div class="connect"><button class="primary" id="open-hq">Waiting for approval</button></div>';document.querySelector('#open-hq').addEventListener('click',()=>chrome.runtime.sendMessage({type:'quadruzz-open-hq'}))}reportReady()}
function signInView(){if(connectInProgress){connectingView();return}requireFullPopup();if(!document.querySelector('#sign-in')){app.innerHTML='<div class="connect"><button class="primary" id="sign-in">Connect to Cross</button></div>';document.querySelector('#sign-in').addEventListener('click',signIn)}reportReady()}
async function signIn(){if(connectInProgress)return;connectInProgress=true;connectingView();try{const result=await chrome.runtime.sendMessage({type:'quadruzz-connect'});if(!result?.ok)throw new Error('Connection tab did not open')}catch{connectInProgress=false;signInView()}}
async function connectionPending(){try{return Boolean((await chrome.runtime.sendMessage({type:'quadruzz-connect-state'}))?.connecting)}catch{return false}}
async function storedImageCache(){if(!storedImageCachePromise)storedImageCachePromise=storage.get('profileImageCache').then(result=>result.profileImageCache||{});return storedImageCachePromise}
function blobDataUrl(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.addEventListener('load',()=>resolve(typeof reader.result==='string'?reader.result:''),{once:true});reader.addEventListener('error',()=>reject(reader.error),{once:true});reader.readAsDataURL(blob)})}
async function memberImage(member,token){const key=`${member.userId}:${member.imageVersion}`;if(imageUrls.has(key))return imageUrls.get(key);if(imageLoads.has(key))return imageLoads.get(key);const load=(async()=>{const cached=await storedImageCache();if(cached[key]){imageUrls.set(key,cached[key]);return cached[key]}const response=await fetch(`${BASE}/api/extension/profile-image?user=${encodeURIComponent(member.userId)}&v=${member.imageVersion}`,{headers:{authorization:`Bearer ${token}`}});if(!response.ok)return'';const url=await blobDataUrl(await response.blob());for(const existing of Object.keys(cached))if(existing.startsWith(member.userId+':')&&existing!==key)delete cached[existing];cached[key]=url;while(Object.keys(cached).length>30)delete cached[Object.keys(cached)[0]];imageUrls.set(key,url);try{await storage.set({profileImageCache:cached})}catch{/* The in-memory image remains usable if storage is temporarily unavailable. */}return url})();imageLoads.set(key,load);try{return await load}finally{imageLoads.delete(key)}}
function formatNoteTime(value){const date=new Date(Number(value));if(Number.isNaN(date.getTime()))return'';const now=new Date();const pad=number=>String(number).padStart(2,'0');return date.toDateString()===now.toDateString()?pad(date.getHours())+':'+pad(date.getMinutes()):pad(date.getMonth()+1)+'/'+pad(date.getDate())}
const noteMeasureContext=document.createElement('canvas').getContext('2d');
function noteUsesTwoLines(value){
  const note=String(value??'');
  if(note.includes('\n'))return true;
  if(!noteMeasureContext)return false;
  noteMeasureContext.font='500 10px system-ui';
  let line='';
  for(const character of note){
    const candidate=line+character;
    if(line&&noteMeasureContext.measureText(candidate).width>153)return true;
    line=candidate;
  }
  return false;
}
function esc(value){const node=document.createElement('span');node.textContent=value??'';return node.innerHTML}
function stopInvalidContext(error){if(!/extension context invalidated/i.test(String(error)))return false;stopped=true;if(refreshTimer)clearInterval(refreshTimer);return true}
function matchingRoles(){const query=roleFilter.trim().toLocaleLowerCase();return (latestData?.roleStatuses||[]).filter(role=>!query||role.toLocaleLowerCase().includes(query))}
function hideOverlayNow(){window.parent.postMessage({type:'quadruzz-hide-now'},'*')}
function closeRolePicker(){if(standaloneRole){pickerOpen=false;standaloneRole=false;roleFilter='';document.querySelector('.role-picker')?.remove();hideOverlayNow();return}pickerOpen=false;roleFilter='';renderMembers()}
function closeNoteEditor(){if(standaloneNote){noteOpen=false;standaloneNote=false;noteDraft='';noteLastValid='';document.querySelector('.note-editor')?.remove();hideOverlayNow();return}noteOpen=false;noteDraft='';noteLastValid='';renderMembers()}
function preparePanel(panel){pendingPanel=panel;window.parent.postMessage({type:'quadruzz-prepare-picker'},'*')}
function requestRolePickerToggle(){if(pickerOpen){closeRolePicker();return}noteOpen=false;selectedRoleIndex=0;roleFilter='';if(standaloneRole||actionPopup){pickerOpen=true;renderMembers();return}preparePanel('role')}
function requestNoteToggle(){if(noteOpen){closeNoteEditor();return}pickerOpen=false;noteDraft='';noteLastValid='';if(standaloneNote||actionPopup){noteOpen=true;renderMembers();return}preparePanel('note')}
function viewSignature(){return JSON.stringify({members:latestData?.members,roles:latestData?.roleStatuses,images:latestImages,pendingRole,pendingNote,pendingNoteSet})}
function rolePickerMarkup(){
  const roles=matchingRoles();
  return `<div class="role-picker"><input class="role-input" id="role-filter" maxlength="30" value="${esc(roleFilter)}" aria-label="Find or create role status" placeholder="Alterar atribuição..." autocomplete="off" spellcheck="false"><div class="role-options">${roles.map((role,index)=>`<button class="role-option" data-index="${index}" type="button">${esc(role)}</button>`).join('')}</div></div>`;
}
function bindRolePicker(){
  if(!pickerOpen)return;
  const input=document.querySelector('#role-filter');
  const options=[...document.querySelectorAll('.role-option')];
  const normalizeSelection=()=>{
    if(!options.length)selectedRoleIndex=-1;
    else if(selectedRoleIndex>=options.length)selectedRoleIndex=0;
  };
  const paintSelection=()=>{
    normalizeSelection();
    input.classList.toggle('selected',selectedRoleIndex===-1);
    options.forEach((button,index)=>button.classList.toggle('selected',selectedRoleIndex===index));
  };
  input.addEventListener('input',event=>{
    roleFilter=event.target.value;
    selectedRoleIndex=matchingRoles().length?0:-1;
    renderMembers();
  });
  input.addEventListener('keydown',event=>{
    if(event.key==='Enter'){
      event.preventDefault();
      if(selectedRoleIndex>=0)void chooseRole(matchingRoles()[selectedRoleIndex],false);
      else if(input.value.trim())void chooseRole(input.value,true);
      return;
    }
    if(event.key==='Escape'){event.preventDefault();closeRolePicker();return}
    if(event.key==='Tab'||event.key==='ArrowDown'||event.key==='ArrowUp'){
      event.preventDefault();
      if(event.repeat)return;
      const backwards=event.shiftKey||event.key==='ArrowUp';
      const count=options.length;
      if(!count)selectedRoleIndex=-1;
      else if(backwards)selectedRoleIndex=selectedRoleIndex===-1?count-1:selectedRoleIndex===0?-1:selectedRoleIndex-1;
      else selectedRoleIndex=selectedRoleIndex===-1?0:selectedRoleIndex===count-1?-1:selectedRoleIndex+1;
      paintSelection();
    }
  });
  options.forEach((button,index)=>{
    button.addEventListener('pointerdown',event=>{
      event.preventDefault();
      event.stopPropagation();
      selectedRoleIndex=index;
      void chooseRole(matchingRoles()[index],false);
    });
  });
  paintSelection();
  input.focus();
  input.setSelectionRange(input.value.length,input.value.length);
}
function noteEditorMarkup(){return `<div class="note-editor"><textarea id="note-input" rows="2" aria-label="Set note" placeholder="Enviar comunicado..." spellcheck="true">${esc(noteDraft)}</textarea></div>`}
function sizeNoteEditor(input){
  const editor=input.closest('.note-editor');
  input.style.height='18px';
  const required=input.scrollHeight;
  if(required>28)return false;
  const height=required>18?28:18;
  input.style.height=height+'px';
  editor.style.height=height+'px';
  const top=Number(editor.dataset.top||0);
  pickerDesiredHeight=top+height;
  reportSize();
  return true;
}
function bindNoteEditor(){
  if(!noteOpen)return;
  const input=document.querySelector('#note-input');
  input.addEventListener('keydown',event=>{
    if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();void saveNote();return}
    if(event.key==='Escape'){event.preventDefault();closeNoteEditor()}
  });
  input.addEventListener('input',()=>{
    if(sizeNoteEditor(input)){noteDraft=input.value;noteLastValid=input.value;return}
    const caret=Math.min(input.selectionStart,noteLastValid.length);
    input.value=noteLastValid;
    noteDraft=noteLastValid;
    sizeNoteEditor(input);
    input.setSelectionRange(caret,caret);
  });
  sizeNoteEditor(input);
  input.focus();
  input.setSelectionRange(input.value.length,input.value.length);
}async function saveNote(value=noteDraft){
  if(savingNote)return;
  const note=String(value).trim().replace(/\r\n?/g,'\n')||null;
  savingNote=true;
  pendingNote=note;
  pendingNoteSet=true;
  const self=latestData?.members.find(member=>member.userId===latestData.currentUserId);
  const previous=self?.note??null;
  const previousUpdatedAt=self?.noteUpdatedAt??null;
  if(self){self.note=note;self.noteUpdatedAt=Date.now();pendingNoteUpdatedAt=self.noteUpdatedAt;}
  const closingStandalone=standaloneNote;
  noteOpen=false;
  noteDraft='';
  noteLastValid='';
  if(closingStandalone)hideOverlayNow();else{renderMembers()}
  try{
    const response=await api('/api/extension',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({note})});
    if(!response.ok)throw new Error();
    const result=await response.json();
    const savedNote=Object.prototype.hasOwnProperty.call(result,'note')?(result.note??null):note;
    if(self){self.note=savedNote;self.noteUpdatedAt=result.noteUpdatedAt??pendingNoteUpdatedAt;}
    pendingNote=savedNote;
    pendingNoteUpdatedAt=result.noteUpdatedAt??pendingNoteUpdatedAt;
    await loadMembers(true);
  }catch(error){
    if(stopInvalidContext(error))return;
    pendingNoteSet=false;
    pendingNote=null;
    if(self){self.note=previous;self.noteUpdatedAt=previousUpdatedAt;}
    void loadMembers(true);
  }finally{savingNote=false;renderMembers()}
}

function layoutRoleLabels(){
  if(roleLayoutFrame!==null)cancelAnimationFrame(roleLayoutFrame);
  roleLayoutFrame=requestAnimationFrame(()=>{
    roleLayoutFrame=null;
    document.querySelectorAll('.member').forEach(member=>{
      const label=member.querySelector('.role-label');
      const name=member.querySelector('.name-label');
      if(!label||!name)return;
      const overlap=Math.max(0,name.getBoundingClientRect().right-label.getBoundingClientRect().left+2);
      name.style.clipPath=overlap?`inset(0 ${overlap}px 0 0)`:'none';
    });
  });
}
new ResizeObserver(layoutRoleLabels).observe(document.documentElement);
function layoutBottom(element){
  let bottom=element?.offsetHeight||0;
  for(let current=element;current&&current!==document.body;current=current.offsetParent)bottom+=current.offsetTop||0;
  return Math.round(bottom);
}
function renderMembers(){
  if(!latestData)return;
  document.querySelectorAll('.role-picker,.note-editor,.note-notifications').forEach(element=>element.remove());
  const rows=latestData.members.map((member,index)=>{
    const self=member.userId===latestData.currentUserId;
    const role=`<span class="role-label">${esc(member.actingState||'-')}</span>`;
    const name=self?`<button class="name own-zone note-trigger" type="button" aria-expanded="${noteOpen}"><span class="name-label">${esc(member.displayName)}</span></button>`:`<span class="name"><span class="name-label">${esc(member.displayName)}</span></span>`;
    const state=self?`<button class="state role-trigger" type="button" aria-expanded="${pickerOpen}">${role}</button>`:`<span class="state role-display">${role}</span>`;
    const twoLineNote=noteUsesTwoLines(member.note);
    const noteIsFresh=!self&&freshNoteUsers.has(member.userId)&&!animatedFreshNoteUsers.has(member.userId);
    const noteClass=`note-label${twoLineNote?' two-lines':''}${self?' own-note':''}`;
    const note=member.note?`${self?`<button class="${noteClass}" type="button" aria-label="Remove note">`:`<span class="${noteClass}" data-note-user="${esc(member.userId)}"${noteIsFresh?' data-note-fresh="true"':''}>`}<span class="note-label-text">${esc(member.note)}</span><span class="note-label-meta">${self?'Remove':esc(formatNoteTime(member.noteUpdatedAt))}</span>${self?'</button>':'</span>'}`:'';
    return `<li class="member${member.extensionActive?'':' inactive'}${self?' self':''}${member.note?' has-note':''}${twoLineNote?' two-line-note':''}"><img class="${latestImages[index]?'image-ready':''}" src="${latestImages[index]||''}" alt="">${name}${state}${note}</li>`;
  }).join('');
  app.innerHTML=`<ul class="members">${rows}</ul>`;
  if(!actionPopup&&overlayVisible)requestAnimationFrame(startFreshNoteAnimations);
  if(actionPopup&&!actionPopupRevealed)document.documentElement.classList.remove('action-popup-pending');
  document.body.insertAdjacentHTML('beforeend',notificationMarkup());

  layoutRoleLabels();

  const ownNote=document.querySelector('.own-note');
  if(ownNote)ownNote.addEventListener('pointerdown',event=>{event.preventDefault();event.stopPropagation();void saveNote('')});
  const roleTrigger=document.querySelector('.role-trigger');
  if(roleTrigger){
    roleTrigger.addEventListener('pointerdown',event=>{event.preventDefault();requestRolePickerToggle()});
    roleTrigger.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();requestRolePickerToggle()}});
  }
  const noteTrigger=document.querySelector('.note-trigger');
  if(noteTrigger){
    noteTrigger.addEventListener('pointerdown',event=>{event.preventDefault();requestNoteToggle()});
    noteTrigger.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();requestNoteToggle()}});
  }
  const notificationsHeight=notificationHeight();
  pickerDesiredHeight=notificationsHeight;
  if(pickerOpen&&roleTrigger){
    document.body.insertAdjacentHTML('beforeend',rolePickerMarkup());
    const picker=document.querySelector('.role-picker');
    const top=standaloneRole?notificationsHeight+(notificationsHeight?2:0):layoutBottom(roleTrigger.closest('.member'))-2;
    picker.style.top=`${top}px`;
    picker.style.left=standaloneRole?'0':'41px';
    picker.style.right=standaloneRole?'auto':'0';
    picker.style.width=standaloneRole?'100%':'auto';
    picker.style.maxHeight=`calc(100vh - ${top}px)`;
    pickerDesiredHeight=top+(matchingRoles().length+1)*24;
  }else if(noteOpen&&noteTrigger){
    document.body.insertAdjacentHTML('beforeend',noteEditorMarkup());
    const editor=document.querySelector('.note-editor');
    const top=standaloneNote?notificationsHeight+(notificationsHeight?2:0):layoutBottom(noteTrigger.closest('.member'))-2;
    editor.style.top=`${top}px`;
    editor.style.left=standaloneNote?'0':'41px';
    editor.style.right=standaloneNote?'auto':'0';
    editor.style.width=standaloneNote?'100%':'auto';
    editor.dataset.top=String(top);
    pickerDesiredHeight=top+18;
  }
  lastRenderSignature=viewSignature();
  bindRolePicker();
  bindNoteEditor();
  reportReady();
}
function updateMemberImages(images){document.querySelectorAll('.member img').forEach((image,index)=>{const url=images[index]||'';image.classList.toggle('image-ready',Boolean(url));if(url&&image.src!==url)image.src=url})}
async function chooseRole(value,create){
  const label=String(value||'').trim().replace(/\s+/g,' ');
  if(!label||label.length>30||savingRole)return;
  savingRole=true;
  pendingRole=label;
  const self=latestData?.members.find(member=>member.userId===latestData.currentUserId);
  const previous=self?.actingState;
  if(self)self.actingState=label;
  const closingStandalone=standaloneRole;
  pickerOpen=false;
  noteOpen=false;
  roleFilter='';
  if(closingStandalone)hideOverlayNow();else{renderMembers()}
  try{
    const response=await api('/api/extension',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({actingState:label,createActingState:create})});
    if(!response.ok)throw new Error();
    const result=await response.json();
    if(self&&result.actingState){self.actingState=result.actingState;pendingRole=result.actingState}
    await loadMembers(true);
  }catch(error){
    if(stopInvalidContext(error))return;
    pendingRole=null;
    if(self)self.actingState=previous;
    void loadMembers(true);
  }finally{savingRole=false;renderMembers()}
}
async function loadMembers(forceRender=false){
  if(stopped)return;
  const sequence=++nextLoadSequence;
  try{
    const{token}=await storage.get('token');
    if(!token){if(await connectionPending())connectingView();else signInView();return}
    const response=await api('/api/extension');
    if(response.status===401){try{await chrome.runtime.sendMessage({type:'quadruzz-access-state',state:'none'})}catch{}latestData=null;latestImages=[];pickerOpen=false;noteOpen=false;try{await chrome.runtime.sendMessage({type:'quadruzz-membership-lost'})}catch{}if(await connectionPending())connectingView();else signInView();return}
    if(!response.ok)throw new Error();
    const data=await response.json();
    if(sequence<appliedAccessSequence)return;
    appliedAccessSequence=sequence;
    if(data.accessState==='pending'){try{await chrome.runtime.sendMessage({type:'quadruzz-access-state',state:'pending'})}catch{}latestData=null;latestImages=[];pickerOpen=false;noteOpen=false;waitingView();return}
    if(data.accessState!=='approved'){try{await chrome.runtime.sendMessage({type:'quadruzz-access-state',state:'none'})}catch{}latestData=null;latestImages=[];pickerOpen=false;noteOpen=false;await storage.remove('token');try{await chrome.runtime.sendMessage({type:'quadruzz-membership-lost'})}catch{}signInView();return}
    try{await chrome.runtime.sendMessage({type:'quadruzz-access-state',state:'approved'})}catch{}
    await pulseActivity();
    data.members.sort((a,b)=>a.displayName.localeCompare(b.displayName,undefined,{sensitivity:'base'}));
    if(actionPopup)void chrome.storage.session.set({cachedMemberSnapshot:data});
    const images=data.members.map(member=>imageUrls.get(member.userId+':'+member.imageVersion)||'');
    const resolvedImages=Promise.all(data.members.map(member=>memberImage(member,token)));
    if(sequence<appliedLoadSequence)return;
    appliedLoadSequence=sequence;
    const self=data.members.find(member=>member.userId===data.currentUserId);
    if(pendingRole){
      if(!savingRole&&self?.actingState===pendingRole)pendingRole=null;
      else if(self)self.actingState=pendingRole;
    }
    if(pendingNoteSet){
      if(!savingNote&&(self?.note??null)===pendingNote){pendingNoteSet=false;pendingNote=null;pendingNoteUpdatedAt=null}
      else if(self){self.note=pendingNote;self.noteUpdatedAt=pendingNoteUpdatedAt;}
    }
    if(overlayVisible&&!standaloneRole&&!standaloneNote&&!standaloneNotification)await markFreshNotes(data);
    latestData=data;
    latestImages=images;
    if(!lastRenderSignature||forceRender||viewSignature()!==lastRenderSignature)renderMembers();
    void resolvedImages.then(nextImages=>{if(sequence<appliedLoadSequence)return;const changed=nextImages.some((image,index)=>image!==latestImages[index]);if(!changed)return;latestImages=nextImages;updateMemberImages(nextImages)}).catch(()=>{});
  }catch(error){if(stopInvalidContext(error))return;reportReady()}
}
async function hydrateActionPopup(){if(!actionPopup)return;const stored=await chrome.storage.session.get('cachedMemberSnapshot');const data=stored.cachedMemberSnapshot;if(data?.accessState!=='approved'||!Array.isArray(data.members))return;data.members.sort((a,b)=>a.displayName.localeCompare(b.displayName,undefined,{sensitivity:'base'}));const cached=await storedImageCache();if(actionMode!=='notification')await markFreshNotes(data);latestData=data;latestImages=data.members.map(member=>cached[`${member.userId}:${member.imageVersion}`]||'');renderMembers()}
function scheduleRefresh(delay=overlayVisible||actionPopup?250:5000){
  if(stopped)return;
  if(refreshTimer)clearTimeout(refreshTimer);
  refreshTimer=setTimeout(async()=>{await loadMembers();scheduleRefresh()},delay);
}
if(actionPopup){
  overlayVisible=true;
  presentationId=1;
  document.documentElement.classList.add('action-popup');
  if(actionMode==='role')pickerOpen=true;
  if(actionMode==='note')noteOpen=true;
  if(actionMode==='notification'){
    standaloneNotification=true;
    document.documentElement.classList.add('standalone-notification');
  }
}
new ResizeObserver(scheduleSizeReport).observe(document.body);
try{const started=chrome.runtime.sendMessage({type:'quadruzz-authenticated'});if(started?.catch)started.catch(()=>{})}catch{/* The background alarm will retry. */}
void (async()=>{
  if(actionPopup&&actionMode==='notification'){
    const stored=await chrome.storage.session.get(['actionPopupNotification','activeNoteNotifications']);
    const active=Array.isArray(stored.activeNoteNotifications)?stored.activeNoteNotifications:[];
    for(const notification of active)addNotification(notification);
    if(!active.length&&stored.actionPopupNotification)addNotification(stored.actionPopupNotification);
  }
  await hydrateActionPopup();
  await loadMembers(false);
  scheduleRefresh();
})();
window.addEventListener('pagehide',()=>{stopped=true;if(refreshTimer)clearTimeout(refreshTimer)});
